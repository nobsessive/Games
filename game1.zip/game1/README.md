This is for solving the puzzle proposed by "毒奶菇” on Yike app.

Run
python game1.py

Following is the puzzle (Chinese)
